import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-raca',
  templateUrl: './raca.page.html',
  styleUrls: ['./raca.page.scss'],
})
export class RacaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
