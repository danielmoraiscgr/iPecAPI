import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fazenda',
  templateUrl: './fazenda.page.html',
  styleUrls: ['./fazenda.page.scss'],
})
export class FazendaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
