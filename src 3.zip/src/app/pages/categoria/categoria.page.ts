import { Component, OnInit } from '@angular/core';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite/ngx';

@Component({
  selector: 'app-categoria',
  templateUrl: './categoria.page.html',
  styleUrls: ['./categoria.page.scss'],
})
export class CategoriaPage implements OnInit {

  databaseObj: SQLiteObject; // Database instance object
  nome:string="";
  
  row_data: any = []; // Table rows
  readonly database_name:string = "ipedDB"; // DB name
  readonly table_name:string = "categoria"; // Table name


  constructor(private sqlite: SQLite){
        
  }

  
  createDB() {

    this.sqlite.create({
       name: this.database_name,
       location: 'default'
     })
       .then((db: SQLiteObject) => {
         this.databaseObj = db;
         this.createTable();
       })
       .catch(e => {
         alert("error " + JSON.stringify(e))
       });
 }

  createTable() {
  this.databaseObj.executeSql('CREATE TABLE IF NOT EXISTS Categoria (pid integer primary key AUTOINCREMENT NOT NULL, nome TEXT NOT NULL)', [])
    .then(() => {
      this.getAll();
    })
    .catch(e => {
      alert("error " + JSON.stringify(e))
    });
}
 

add() {
  if (!this.nome.length) {
    alert("Entre com o nome !");
    return;
  }
 this.databaseObj.executeSql('INSERT INTO ' + this.table_name + ' (nome) VALUES ("' + this.nome+ '")', [])
    
  .then(() => {
      alert('Categoria Inserida !');
      this.nome="";
      this.getAll();
    })
    .catch(e => {
      alert("error " + JSON.stringify(e))
    });
   
  }

  getAll() {
    this.databaseObj.executeSql("SELECT * FROM " + this.table_name, [])
      .then((res) => {
        this.row_data = [];
        if (res.rows.length > 0) {
          for (var i = 0; i < res.rows.length; i++) {
            this.row_data.push(res.rows.item(i));
          }
        }
      })
      .catch(e => {
        alert("error " + JSON.stringify(e))
      });
  }


delete(item) {
  this.databaseObj.executeSql("DELETE FROM " + this.table_name + " WHERE pid = " + item.pid, [])
    .then((res) => {
      alert("Categoria removida !");
      this.getAll();
    })
    .catch(e => {
      alert("error " + JSON.stringify(e))
    });
}


  update() {
      

  }

  /*async showToast(msg){
    const toast = await this.toastController.create({
      message: msg, 
      duration: 2000
      });
      toast.present(); 
  }
  */

  ngOnInit() {
    this.createDB();    
  }



}
