import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tipomanejo',
  templateUrl: './tipomanejo.page.html',
  styleUrls: ['./tipomanejo.page.scss'],
})
export class TipomanejoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
