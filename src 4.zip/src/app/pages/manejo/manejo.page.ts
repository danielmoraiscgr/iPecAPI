import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manejo',
  templateUrl: './manejo.page.html',
  styleUrls: ['./manejo.page.scss'],
})
export class ManejoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
