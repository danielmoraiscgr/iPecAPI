import { Component, OnInit,  ViewChildren  } from '@angular/core';

//import { SQLite, SQLiteObject } from '@ionic-native/sqlite/ngx';

import { ProdutorService, Produtor} from '../../services/produtor.service';
import { Platform, ToastController  } from '@ionic/angular'; 


@Component({
  selector: 'app-produtor',
  templateUrl: './produtor.page.html',
  styleUrls: ['./produtor.page.scss'],
})
export class ProdutorPage implements OnInit {
 
  produtores: Produtor[] = [];
  
  newProdutor: Produtor = <Produtor>{};

  @ViewChildren('mylist')mylist: { closeSlidingItems: () => void; }; 

  constructor(private storageService: ProdutorService, private plt: Platform, private toastController: ToastController){
      this.plt.ready().then(() => {
           this.loadProdutores(); 
      });

  }
  
  addProdutor() {
       this.newProdutor.id = Date.now(); 
       this.storageService.addProdutor(this.newProdutor).then(produtor=> {
            this.newProdutor = <Produtor>{};
            this.showToast('Produtor adicionado  ');
            this.loadProdutores();
       })
  }

  loadProdutores(){
       this.storageService.getProdutores().then(produtores => {
         this.produtores= produtores;
       });
  }

  updateProdutor(produtor: Produtor) {
      produtor.nome = 'UPDATE: $(produtor.nome}';

      this.storageService.updateProdutor(produtor).then(( produtor => {
          this.showToast(' Produtor atualizado !');
          this.mylist.closeSlidingItems();
          this.loadProdutores();

      }))

  }

  deleteProdutor(produtor: Produtor){
      this.storageService.deleteProdutor(produtor.id).then((produtor => {
         this.showToast(' Produtor removido !'); 
        // this.mylist.closeSlidingItems();
         this.loadProdutores();
      }))
  }

  async showToast(msg){
    const toast = await this.toastController.create({
      message: msg, 
      duration: 2000
      });
      toast.present(); 
  }
  
  ngOnInit() {

    
  }



}
