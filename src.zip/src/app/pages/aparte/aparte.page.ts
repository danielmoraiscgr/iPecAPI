import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aparte',
  templateUrl: './aparte.page.html',
  styleUrls: ['./aparte.page.scss'],
})
export class ApartePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
